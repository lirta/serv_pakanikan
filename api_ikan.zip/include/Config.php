<?php
define("DB_HOST", "localhost");

//  define("DB_USER", "pramudi1_lirta");
//  define("DB_PASSWORD", "IiZmu;6n24u2");
//  define("DB_DATABASE", "pramudi1_pakan_ikan");



define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "ikan");


?>